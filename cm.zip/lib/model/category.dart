import 'package:hive/hive.dart';

part 'category.g.dart';

@HiveType(typeId: 0)
class Category {
  Category(
      {required this.index, required this.title, required this.categoryId});
  @HiveField(0)
  int index;
  @HiveField(1)
  String title;
  @HiveField(2)
  int categoryId;

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      index: json['index'] ?? 0,
      title: json['title'] ?? '',
      categoryId: json['categoryId'],
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> data = {};
    data['index'] = index;
    data['title'] = title;
    data['categoryId'] = categoryId;
    return data;
  }

  @override
  String toString() {
    return title + categoryId.toString();
  }
}
