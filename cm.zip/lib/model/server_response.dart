class ServerResponse {
  final int code;
  final String message;
  ServerResponse({required this.code, required this.message});
}
