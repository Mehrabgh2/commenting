import 'package:commenting/db/Boxes.dart';
import 'package:commenting/model/category.dart';

class CategoryDBProvider {
  static final CategoryDBProvider _singleton = CategoryDBProvider._internal();
  factory CategoryDBProvider() => _singleton;
  CategoryDBProvider._internal();

  List<Category> getCategories() {
    List<Category> categories = [];
    for (Map<dynamic, dynamic> element in Boxes.getCategories().values) {
      Map<String, dynamic> map = Map.fromEntries(element.entries
          .map((entry) => MapEntry(entry.key.toString(), entry.value)));
      categories.add(Category.fromJson(map));
    }
    return categories;
  }

  bool containCategory(int categoryId) {
    for (Category item in getCategories()) {
      if (item.categoryId == categoryId) return true;
    }
    return false;
  }

  void addCategory(Category category) async {
    if (!containCategory(category.categoryId)) {
      Boxes.getCategories().add(category.toJson());
    }
  }

  void removeCategory(int categoryId) async {
    int index = getCategories()
        .indexWhere((element) => element.categoryId == categoryId);
    Boxes.getCategories().deleteAt(index);
  }

  void clear() {
    Boxes.getCategories().clear();
  }
}
