import 'package:commenting/model/category.dart';
import 'package:flutter/material.dart';

class CategoryRow extends StatelessWidget {
  const CategoryRow({
    Key? key,
    required this.category,
    required this.onDelete,
  }) : super(key: key);

  final Category category;
  final Function onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 75,
      decoration: BoxDecoration(
        color: Theme.of(context).backgroundColor,
        borderRadius: BorderRadius.all(
          Radius.circular(20),
        ),
      ),
      child: Row(
        children: [
          Text(category.title),
          IconButton(
              onPressed: onDelete(category), icon: Icon(Icons.delete_rounded)),
        ],
      ),
    );
  }
}
