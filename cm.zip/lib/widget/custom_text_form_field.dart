import 'package:flutter/material.dart';

class CustomTextFormField extends StatefulWidget {
  const CustomTextFormField(
      {Key? key,
      required this.setter,
      this.minChars,
      this.maxChars,
      this.title = '',
      this.hint = ''})
      : super(key: key);

  final int? minChars;
  final int? maxChars;
  final String title;
  final String hint;
  final Function setter;

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: TextFormField(
        initialValue: widget.title,
        style: TextStyle(color: Color(0xFFB1B5BA)),
        keyboardType: TextInputType.multiline,
        decoration: InputDecoration(
          suffixIcon: const Icon(
            Icons.search,
            color: Color(0xFFB1B5BA),
          ),
          labelText: widget.hint,
          labelStyle: TextStyle(color: Color(0xFFB1B5BA)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: const BorderSide(
              color: Color(0xFFB1B5BA),
            ),
          ),
        ),
        onSaved: (value) => widget.setter(value),
        validator: (value) {
          if (value != null) {
            if (value.isEmpty) {
              return 'Fill text field';
            }
            if (!value.startsWith('http')){
              return 'Enter valid site address';
            } if (widget.minChars != null) {
              if (value.length < widget.minChars!) {
                return 'Minimum character is ${widget.minChars}';
              }
            }
            if (widget.maxChars != null) {
              if (value.length > widget.maxChars!) {
                return 'Maximum character is ${widget.maxChars}';
              }
            }
          }
          return null;
        },
      ),
    );
  }
}
