import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Style {
  static final Style _singleton = Style._internal();
  factory Style() => _singleton;
  Style._internal();

  TextStyle getTextStyle() {
    return const TextStyle(
      color: Colors.white,
    );
  }
}
