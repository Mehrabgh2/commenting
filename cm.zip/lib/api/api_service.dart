import 'package:commenting/core/text_formatter.dart';
import 'package:commenting/model/category.dart';
import 'package:commenting/model/server_response.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';

class ApiService {
  static var dio = Dio();

  static Future<Either<String, ServerResponse>> getProductCategoryLink(
      String link) async {
    var request = RequestOptions(
        path: link, contentType: 'application/json', method: 'GET');
    try {
      Response response = await dio.fetch(request).catchError((onError) {
        return onError.response;
      });
      if (response.statusCode == 200) {
        String _link = response.headers.map['link'] != null
            ? response.headers.map['link']![1]
            : '0';
        return Left(TextFormatter().extractProductLink(_link));
      } else {
        return Right(response.data['message']);
      }
    } catch (ex) {
      return Right(ServerResponse(code: 0, message: 'Something went wrong'));
    }
  }

  static Future<Either<String, ServerResponse>> getProductCategoryName(
      String link) async {
    var request = RequestOptions(
        path: link, contentType: 'application/json', method: 'GET');

    try {
      Response response = await dio.fetch(request).catchError((onError) {
        return onError.response;
      });
      if (response.statusCode == 200) {
        return Left(response.data['name']);
      } else {
        return Right(response.data['message']);
      }
    } catch (ex) {
      return Right(ServerResponse(code: 0, message: 'Something went wrong'));
    }
  }

  static Future<Either<Category, String>> getProductCategory(
      String link) async {
    var getLinkTemp = await getProductCategoryLink(link);
    if (getLinkTemp.isRight()) {
      return Right(getLinkTemp.fold((l) => '', (r) => r.message));
    }
    String productLink = getLinkTemp.fold((l) => l, (r) => '');
    var getNameTemp = await getProductCategoryName(productLink);
    if (getNameTemp.isRight()) {
      return Right(getNameTemp.fold((l) => '', (r) => r.message));
    }
    return Left(
      getNameTemp.fold(
        (l) => Category(
            index: 0,
            title: l,
            categoryId: TextFormatter().extractProductId(productLink)),
        (r) => Category(index: 0, title: '', categoryId: 0),
      ),
    );
  }
}
