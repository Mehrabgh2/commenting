import 'package:hive/hive.dart';

class Boxes {
  static Box<Map<dynamic, dynamic>> getCategories() =>
      Hive.box<Map<dynamic, dynamic>>("categories");
}
