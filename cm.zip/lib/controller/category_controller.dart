import 'package:commenting/api/api_service.dart';
import 'package:commenting/db/category_db_provider.dart';
import 'package:commenting/model/category.dart';
import 'package:dartz/dartz.dart';
import 'package:get/get.dart';

class CategoryController extends GetxController {
  final CategoryDBProvider _categoryDBProvider = CategoryDBProvider();

  @override
  onInit() {
    updateDBCategories();
    super.onInit();
  }

  RxList<Category> dbCategories = RxList([]);

  updateDBCategories() {
    dbCategories.value = CategoryDBProvider().getCategories();
    dbCategories.refresh();
  }

  void removeCategory(Category category) {
    _categoryDBProvider.removeCategory(category.categoryId);
  }

  Future<Either<Category, String>> getCategoryFromLink(String link) async {
    var temp = await ApiService.getProductCategory(link);
    temp.fold(
      (l) => _categoryDBProvider.addCategory(l),
      (r) => print(r),
    );
    return temp;
  }
}
