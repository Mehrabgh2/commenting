import 'package:commenting/controller/category_controller.dart';
import 'package:commenting/model/category.dart';
import 'package:commenting/widget/category_row.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class CategoryListView extends StatelessWidget {
  CategoryController categoryController = Get.find<CategoryController>();

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: categoryController.dbCategories.value.length,
        itemBuilder: (context, index) {
          return CategoryRow(
            category: categoryController.dbCategories.value.elementAt(index),
            onDelete: onDeleteCategory,
          );
        });
  }

  void onDeleteCategory(Category category) {
    categoryController.removeCategory(category);
  }
}
