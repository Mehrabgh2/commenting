import 'dart:io';
import 'package:commenting/model/category.dart';
import 'package:commenting/screen/category_screen.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  HttpOverrides.global = MyHttpOverrides();
  await Hive.initFlutter();
  Hive.registerAdapter(CategoryAdapter());
  await Hive.openBox<Map<dynamic, dynamic>>("categories");
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        backgroundColor: const Color(0xFF121421), // background color
        cardColor:
            const Color(0xFF1B1F30), // card color and bottom app bar color
        buttonColor: const Color(0xFF4353FE), // button color
        textSelectionColor: const Color(0xFFFBFBFD), // header color
        secondaryHeaderColor: const Color(0xFF5A5E6F), // second text color
        hoverColor: const Color(0xFFC0C3CF), // third text color
        highlightColor: const Color(0xFF4A81F0), // selected icon color
        accentColor: const Color(0xFF6A7196), // unselected icon color
        errorColor: const Color(0xFFDE74A4), // error color
        indicatorColor: const Color(0xFF52C58B), // error color
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: CategoryScreen(),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
