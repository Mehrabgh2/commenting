import 'package:commenting/controller/category_controller.dart';
import 'package:commenting/widget/custom_progress_button.dart';
import 'package:commenting/widget/custom_text_form_field.dart';
import 'package:commenting/widget/toast_message.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class AddCategoryBottomSheet extends StatelessWidget {
  String link = '';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final CategoryController categoryController = Get.put(CategoryController());
  late final CustomProgressButton customProgressButton;

  AddCategoryBottomSheet({Key? key}) : super(key: key);

  void setLink(String newValue) {
    link = newValue;
  }

  @override
  Widget build(BuildContext context) {
    void getCategory() async {
      _formKey.currentState!.save();
      if (!_formKey.currentState!.validate()) {
        return;
      }
      customProgressButton.setStatus(ButtonStatus.loading);
      var temp = await categoryController.getCategoryFromLink(link);
      temp.fold((category) {
        customProgressButton.setStatus(ButtonStatus.idle);
        Navigator.of(context).pop();
        ToastMessage.showSuccessToast(
            context: context,
            title: 'Added',
            text: 'دسته بندی ${category.title} با موفقیت اضافه شد');
      }, (r) {
        customProgressButton.setStatus(ButtonStatus.idle);
        Navigator.of(context).pop();
        ToastMessage.showErrorToast(context: context, title: 'Error', text: r);
      });
    }

    customProgressButton = CustomProgressButton(
        idleText: 'Add Category',
        loadingText: 'Please Wait',
        onPressed: getCategory);
    return AnimatedPadding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      duration: const Duration(milliseconds: 350),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Form(
            key: _formKey,
            child: CustomTextFormField(
              setter: setLink,
              hint: 'link',
            ),
          ),
          customProgressButton
        ],
      ),
    );
  }
}
