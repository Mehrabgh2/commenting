import 'package:commenting/widget/add_category_bottom_sheet.dart';
import 'package:commenting/widget/category_listview.dart';
import 'package:flutter/material.dart';

class CategoryScreen extends StatelessWidget {
  final AddCategoryBottomSheet _addCategoryBottomSheet =
      AddCategoryBottomSheet();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: CategoryListView(),
      // ElevatedButton(
      //   child: const Text('showModalBottomSheet'),
      //   onPressed: () {
      //     showModalBottomSheet<void>(
      //       isScrollControlled: true,
      //       useRootNavigator: true,
      //       shape: RoundedRectangleBorder(
      //         borderRadius: BorderRadius.circular(15.0),
      //       ),
      //       context: context,
      //       builder: (BuildContext context) {
      //         return _addCategoryBottomSheet;
      //       },
      //     );
      //   },
      // ),
    );
  }
}
