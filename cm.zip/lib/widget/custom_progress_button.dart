import 'package:commenting/controller/progress_button_controller.dart';
import 'package:commenting/core/style.dart';
import 'package:get/get.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:flutter/material.dart';

enum ButtonStatus {
  idle,
  loading,
}

class CustomProgressButton extends StatelessWidget {
  CustomProgressButton({
    Key? key,
    required this.idleText,
    required this.loadingText,
    required this.onPressed,
  }) : super(key: key);

  final String idleText;
  final String loadingText;
  final Function onPressed;
  final ProgressButtonController progressButtonController =
      Get.put(ProgressButtonController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => progressButtonController.buttonStatus.value == ButtonStatus.idle
          ? _createIdle()
          : _createLoading(),
    );
  }

  void setStatus(ButtonStatus newStatus) {
    progressButtonController.updateButtonStatus(newStatus);
  }

  Widget _createIdle() {
    return Container(
      height: 100,
      padding: const EdgeInsets.all(20),
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
              side: const BorderSide(color: Colors.blue),
            ),
          ),
        ),
        onPressed: () => onPressed(),
        child: Center(
          child: Text(
            idleText,
            style: Style().getTextStyle(),
          ),
        ),
      ),
    );
  }

  Widget _createLoading() {
    return Container(
      height: 100,
      padding: const EdgeInsets.all(20),
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
              side: const BorderSide(color: Colors.blue),
            ),
          ),
        ),
        onPressed: null,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 15),
              child: LoadingIndicator(
                indicatorType: Indicator.ballPulseSync,
                colors: [
                  Colors.red,
                  Colors.amber,
                  Colors.green,
                ],
              ),
            ),
            const SizedBox(width: 20),
            Text(
              loadingText,
              style: Style().getTextStyle(),
            ),
          ],
        ),
      ),
    );
  }
}
