import 'package:flutter/material.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';

class ToastMessage {
  static void showSuccessToast({
    required BuildContext context,
    required String title,
    required String text,
  }) {
    final _devSize = MediaQuery.of(context).size;
    MotionToast.success(
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      description: Text(
        text,
        style: const TextStyle(fontSize: 15),
      ),
      layoutOrientation: ToastOrientation.rtl,
      animationType: AnimationType.fromRight,
      width: _devSize.width / 1.25,
      height: 100,
      dismissable: true,
      enableAnimation: true,
      toastDuration: const Duration(seconds: 5),
      animationCurve: Curves.ease,
      iconType: IconType.materialDesign,
    ).show(context);
  }

  static void showErrorToast({
    required BuildContext context,
    required String title,
    required String text,
  }) {
    final _devSize = MediaQuery.of(context).size;
    MotionToast.error(
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      description: Text(
        text,
        style: const TextStyle(fontSize: 15),
      ),
      layoutOrientation: ToastOrientation.rtl,
      animationType: AnimationType.fromRight,
      width: _devSize.width / 1.25,
      height: 100,
      dismissable: true,
      enableAnimation: true,
      toastDuration: const Duration(seconds: 5),
      animationCurve: Curves.ease,
      iconType: IconType.materialDesign,
    ).show(context);
  }
}
